package com.company.hello.member;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MemberController {
	
	@RequestMapping("/signUp")
	public String signUp() {
		return "sign_up";
	}
	
	@RequestMapping("/signIn")
	public String signIn() {
		return "sign_in";
	}
	
	@RequestMapping("/signUpConfirm")
	public String signUpConfirm(@RequestParam String m_id,
								@RequestParam String m_pw,
								@RequestParam String m_mail,
								@RequestParam String m_phone) {
		System.out.println("사인업컨펌");
		System.out.println("아이디:" + m_id);
		System.out.println("비밀번호:" + m_pw);
		System.out.println("이메일:" + m_mail);
		System.out.println("전화번호:" + m_phone);
		
		return "";
		
	@RequestMapping("/signInConfirm")
	public String signInConfirm() {
		return "";
	}
	}
}
