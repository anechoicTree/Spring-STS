package com.kh.quiz;

public interface QuizService {
	public abstract QuizDO submitAnswer(QuizDO quizDO);
}
